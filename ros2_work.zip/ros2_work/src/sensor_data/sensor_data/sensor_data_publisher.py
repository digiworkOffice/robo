#!/usr/bin/env python3
import rclpy
from std_msgs.msg import String
import serial
from rclpy.node import Node

class SerialDataListenerNode(Node):
    def __init__(self):
        super().__init__("serial_data_listener_node")
        self.publisher_ = self.create_publisher(String, '/serial_data', 10)
        self.serial_port = serial.Serial('/dev/ttyACM0', 115200)

        self.get_logger().info("Serial Data Listener Node Initialized")

    def listen_serial_data(self):
        while True:
            line = self.serial_port.readline().decode('utf-8').strip()
            msg = String()
            msg.data = line
            self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = SerialDataListenerNode()
    node.listen_serial_data()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
