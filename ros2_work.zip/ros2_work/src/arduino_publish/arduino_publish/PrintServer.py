#!/usr/bin/env python3

import rclpy
from std_msgs.msg import String
from example_interfaces.srv import AddTwoInts


class PrintServer:

    def __init__(self):
        self.node = rclpy.create_node('print_server')
        self.service = self.node.create_service(AddTwoInts, 'add_two_ints', self.add_two_ints_callback)
        self.node.get_logger().info('Print server is ready.')

    def add_two_ints_callback(self, request, response):
        response.sum = request.a + request.b
        self.node.get_logger().info(f"Received request: {request.a} + {request.b} = {response.sum}")
        return response


def main(args=None):
    rclpy.init(args=args)
    server = PrintServer()
    rclpy.spin(server.node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
