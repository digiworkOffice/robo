#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
import time
from pynput import keyboard

class MyNode(Node):
    def __init__(self):
        super().__init__("Bool_Publisher_Node")
        self.get_logger().info("Hello from ROS2")
        self.publisher_ = self.create_publisher(Bool, '/robot/arms/wave', 10)
        self.listener = keyboard.Listener(on_press=self.on_press)


    def on_press(self, key):
        try:
            value = Bool()
            if key == keyboard.Key.caps_lock:
                self.get_logger().info("wave")   
                value.data= True
            elif key == keyboard.Key.shift:
                self.get_logger().info("donot wave")
                value.data= False
            else:
                return  

            self.publisher_.publish(value)
            self.get_logger().info(f"Keyboard::: ({value.data}")

        except AttributeError:
            pass

def main(args=None):
    rclpy.init(args=args)
    node = MyNode()

    # Start the keyboard listener
    node.listener.start()

    rclpy.spin(node)

    # Stop the keyboard listener
    node.listener.stop()

    rclpy.shutdown()

if __name__ == '__main__':
    main()
