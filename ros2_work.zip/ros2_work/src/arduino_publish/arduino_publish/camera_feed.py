#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2


class CameraPublisher(Node):
    def __init__(self):
        super().__init__("Camera_Publisher_Node")
        self.get_logger().info("Initializing Camera Publisher Node")
        self.publisher_ = self.create_publisher(Image, '/image_raw', 10)
        self.bridge = CvBridge()

    def publish_camera_feed(self):
        cap = cv2.VideoCapture(0)

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                self.get_logger().warn("Cannot receive frame, exiting...")
                break

            # Convert the frame to ROS Image message
            ros_image = self.bridge.cv2_to_imgmsg(frame, "bgr8")

            # Publish the ROS Image message
            self.publisher_.publish(ros_image)

            # cv2.imshow('img', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()


def main(args=None):
    rclpy.init(args=args)
    node = CameraPublisher()
    try:
        node.publish_camera_feed()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
