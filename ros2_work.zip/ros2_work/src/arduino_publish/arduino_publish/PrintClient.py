#!/usr/bin/env python3

import rclpy
from std_msgs.msg import String

def print_callback(msg):
    print("Received:", msg.data)

def main():
    rclpy.init()
    node = rclpy.create_node('print_server')
    subscriber = node.create_subscription(String, 'print_topic', print_callback, 10)
    print("Print server is ready.")
    rclpy.spin(node)

if __name__ == '__main__':
    main()
