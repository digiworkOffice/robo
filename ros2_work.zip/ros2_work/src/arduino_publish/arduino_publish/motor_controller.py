#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from pynput import keyboard

class MyNode(Node):
    def __init__(self):
        super().__init__("Keyboard_Listener_Node")
        self.get_logger().info("Hello from ROS2")
        self.publisher_ = self.create_publisher(Twist, '/keyboard_input', 10)
        self.listener = keyboard.Listener(on_press=self.on_press)

    def on_press(self, key):
        try:
            twist = Twist()
            if key == keyboard.Key.up:
                self.get_logger().info("Forward")
                twist.linear.x = 9.0
                twist.linear.y = 11.0
            elif key == keyboard.Key.down:
                self.get_logger().info("Backward")
                twist.linear.x = 11.0
                twist.linear.y = 9.0  
                
            elif key == keyboard.Key.left:
                self.get_logger().info("Left")
                twist.linear.x =11.0
                twist.linear.y = 11.0
            elif key == keyboard.Key.right:
                self.get_logger().info("Right")
                twist.linear.x = 9.0
                twist.linear.y = 9.0
            elif key == keyboard.Key.space:
                self.get_logger().info("stop")
                twist.linear.x = 10.0
                twist.linear.y = 10.0
            else:
                return  

            self.publisher_.publish(twist)
        except AttributeError:
            pass

def main(args=None):
    rclpy.init(args=args)
    node = MyNode()

    # Start the keyboard listener
    node.listener.start()

    rclpy.spin(node)

    # Stop the keyboard listener
    node.listener.stop()

    rclpy.shutdown()

if __name__ == '__main__':
    main()