#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from std_msgs.msg import Bool
from geometry_msgs.msg import Twist
import serial
import threading

class TwistSubscriberNode(Node):
    def __init__(self):
        super().__init__("Arduino_Node")
        self.get_logger().info("Node Initialized")
        self.serial_port = serial.Serial('/dev/ttyACM0', 115200, timeout=1)
        self.publisher_ = self.create_publisher(String, '/serial_data', 10)
        self.lefthand_data = 0
        self.righthand_data = 0
        self.face_data = 5
        self.left_Wheel = 0
        self.right_Wheel = 0
        # data received from keyboard
        self.left_Wheel_data = 10
        self.right_Wheel_data =10
        self.keyboard_subscription = self.create_subscription(
            Twist,
            '/keyboard_input',
            self.keyboard_callback,
            10
        )

        self.face_subscription = self.create_subscription(
            String,                                      
            '/detected_face_coordinates',
            self.face_callback,
            10
        )

        self.wave_subscription = self.create_subscription(
            Bool,                                      
            '/robot/arms/wave',
            self.wave_identification_callback,
            10
        )

        self.move_subscription = self.create_subscription(
            Bool,                                      
            '/robot/move/front',
            self.identification_move_callback,
            10
        )



        self.serial_receive_thread = threading.Thread(target=self.receive_data_from_serial)
        self.serial_receive_thread.daemon = True
        self.serial_receive_thread.start()


    def keyboard_callback(self, msg):
        self.left_Wheel_data = int(msg.linear.x)
        self.right_Wheel_data = int(msg.linear.y)

        self.left_Wheel = self.left_Wheel_data
        self.right_Wheel = self.right_Wheel_data

        self.send_data_to_arduino()


    def face_callback(self, msg):
        self.face_data = msg.data
        self.send_data_to_arduino()


    def wave_identification_callback(self, msg):
        if(msg.data==True):
            self.lefthand_data = 1
            self.send_data_to_arduino()
        else:
            self.lefthand_data = 0
            self.send_data_to_arduino()


    
    def identification_move_callback(self, msg):
        if(msg.data==True):
            self.left_Wheel = 9
            self.right_Wheel = 11
            self.send_data_to_arduino()
        else:
            self.left_Wheel = self.left_Wheel_data
            self.right_Wheel = self.left_Wheel_data
            self.send_data_to_arduino()




    def send_data_to_arduino(self):
        data_to_send = f"<{self.lefthand_data},{self.righthand_data},{self.face_data},{self.left_Wheel},{self.right_Wheel}>"
        self.get_logger().info(f"Sending data to Arduino: {data_to_send}")
        self.serial_port.write(data_to_send.encode())


    def receive_data_from_serial(self):
        while True:
            try:
                line = self.serial_port.readline().decode('utf-8').strip()
                self.get_logger().info(f"Received data from Arduino: {line}" )
                msg = String()
                msg.data = line
                self.publisher_.publish(msg)
            except UnicodeDecodeError:
                pass

def main(args=None):
    rclpy.init(args=args)
    node = TwistSubscriberNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
