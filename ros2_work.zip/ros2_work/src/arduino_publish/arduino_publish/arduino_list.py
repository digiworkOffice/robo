#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist
import serial
import threading

class TwistSubscriberNode(Node):
    def __init__(self):
        super().__init__("Arduino_Node")
        self.get_logger().info("Node Initialized")
        self.serial_port = serial.Serial('/dev/ttyACM0', 115200, timeout=1)
        self.publisher_ = self.create_publisher(String, '/serial_data', 10)
        self.lefthand_data = 0
        self.righthand_data = 0
        self.face_data = 5
        self.linear_x = 0
        self.linear_y = 0
        self.keyboard_subscription = self.create_subscription(
            Twist,
            '/keyboard_input',
            self.keyboard_callback,
            10
        )

        self.face_subscription = self.create_subscription(
            String,
            '/detected_face_coordinates',
            self.face_callback,
            10
        )

        self.serial_receive_thread = threading.Thread(target=self.receive_data_from_serial)
        self.serial_receive_thread.daemon = True
        self.serial_receive_thread.start()


    def keyboard_callback(self, msg):
        self.linear_x = int(msg.linear.x)
        self.linear_y = int(msg.linear.y)
        self.send_data_to_arduino()


    def face_callback(self, msg):
        self.face_data = msg.data
        self.send_data_to_arduino()


    def send_data_to_arduino(self):
        data_to_send = f"<{self.lefthand_data},{self.righthand_data},{self.face_data},{self.linear_x},{self.linear_y}>"
        self.get_logger().info(f"Sending data to Arduino: {data_to_send}")
        self.serial_port.write(data_to_send.encode())


    def receive_data_from_serial(self):
        while True:
            try:
                line = self.serial_port.readline().decode('utf-8').strip()
                self.get_logger().info(f"Received data from Arduino: {line}" )
                msg = String()
                msg.data = line
                self.publisher_.publish(msg)
            except UnicodeDecodeError:
                pass

def main(args=None):
    rclpy.init(args=args)
    node = TwistSubscriberNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
