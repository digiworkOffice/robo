#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class KeyboardListener(Node):
    def __init__(self):
        super().__init__("Keyboard_Listener")
        self.subscription = self.create_subscription(String, '/detected_face_coordinates', self.listener_callback, 10)
        self.subscription
        self.get_logger().info("Listening to head track input...")

    def listener_callback(self, msg):
        self.get_logger().info(f"Received head track: {msg.data}")

def main(args=None):
    rclpy.init(args=args)
    node = KeyboardListener()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
