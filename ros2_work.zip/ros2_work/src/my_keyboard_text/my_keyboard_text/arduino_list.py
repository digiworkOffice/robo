#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist
import serial

class TwistSubscriberNode(Node):
    def __init__(self):
        super().__init__("Twist_Subscriber_Node")
        self.get_logger().info("Twist Subscriber Node Initialized")
        self.subscription = self.create_subscription(
            Twist,
            '/keyboard_input',
            self.listener_callback,
            10
        )
        self.subscription  # Prevent unused variable warning
        # Open serial connection to Arduino (replace '/dev/ttyUSB0' with your Arduino's port)
        self.serial_port = serial.Serial('/dev/ttyACM0', 9600, timeout=1)

    def listener_callback(self, msg):
        # Extract linear x and y components from Twist message
        linear_x = msg.linear.x
        linear_y = msg.linear.y

        # Send Twist message data over serial to Arduino
        self.serial_port.write(f"{linear_x},{linear_y}\n".encode())

def main(args=None):
    rclpy.init(args=args)
    node = TwistSubscriberNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
