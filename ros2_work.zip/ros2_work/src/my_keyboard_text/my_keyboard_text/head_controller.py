#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
from std_msgs.msg import String
import numpy as np


class FaceDetector(Node):
    def __init__(self):
        super().__init__("Face_Detector_Node")
        self.get_logger().info("Initializing Face Detector Node")
        self.subscription = self.create_subscription(Image, '/image_raw', self.image_callback, 10)
        self.subscription  # prevent unused variable warning
        self.publisher_ = self.create_publisher(String, '/detected_face_coordinates', 10)
        self.bridge = CvBridge()
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')


    def image_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")

        # Convert frame to grayscale for face detection
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detect faces in the grayscale frame
        faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)

        if faces is not None and len(faces) > 0:
            # Find the largest face
            largest_face = max(faces, key=lambda rect: rect[2] * rect[3])
            x, y, w, h = largest_face
            face_center_x = x + w // 2
            head_position_angle = int(np.interp(face_center_x, [0, frame.shape[1]], [0, 10]))
            self.publish_face_coordinates(head_position_angle)

            cv2.circle(frame, (x + w // 2, y + h // 2), 2, (0, 255, 0), 2)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 3)
        # else:
            # self.get_logger().info("No faces detected")

        cv2.rectangle(frame, (640 // 2 - 30, 480 // 2 - 30),
                      (640 // 2 + 30, 480 // 2 + 30),
                      (255, 255, 255), 3)

        cv2.imshow('img', frame)
        cv2.waitKey(1)


    def publish_face_coordinates(self, value):
        face_point = String()
        face_point.data = str(value)  # Convert value to string
        # Publish the Point message containing face coordinates
        self.publisher_.publish(face_point)

        self.get_logger().info(f"Detected face at: ({value}")


def main(args=None):
    rclpy.init(args=args)
    node = FaceDetector()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
