#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial
import time

class MyNode(Node):
    def __init__(self):
        super().__init__("Keyboard_Listener_Node")
        self.get_logger().info("Hello from ROS2")
        self.publisher_ = self.create_publisher(Twist, '/keyboard_input', 10)
        self.serial_port = serial.Serial('/dev/ttyACM0', 9600)  
        time.sleep(2)  # Allow time for serial connection to stabilize

    def send_serial_command(self, cmd):
        self.serial_port.write(cmd.encode())

    def on_command_received(self, twist):
        cmd = f"{1 if twist.linear.x != 0 else 0},{1 if twist.linear.y != 0 else 0}"
        self.get_logger().info("Sending command: " + cmd)
        self.send_serial_command(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = MyNode()

    def callback(msg):
        node.on_command_received(msg)

    # Subscribe to the keyboard_input topic
    node.create_subscription(Twist, 'keyboard_input', callback, 10)

    rclpy.spin(node)

    # Clean up
    node.serial_port.close()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
