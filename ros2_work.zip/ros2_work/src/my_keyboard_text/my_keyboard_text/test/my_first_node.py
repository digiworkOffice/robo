#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from pynput import keyboard

class MyNode(Node):
    def __init__(self):
        super().__init__("Keyboard_Listener_Node")
        self.get_logger().info("Hello from ROS2")
        self.publisher_ = self.create_publisher(String, 'keyboard_input', 10)
        self.listener = keyboard.Listener(on_press=self.on_press)

    def on_press(self, key):
        try:
            # Filter only arrow key presses
            if key == keyboard.Key.up:
                self.get_logger().info("Forward")
                msg = String()
                msg.data = "Forward"
                self.publisher_.publish(msg)
            elif key == keyboard.Key.down:
                self.get_logger().info("Backward")
                msg = String()
                msg.data = "Backward"
                self.publisher_.publish(msg)
            elif key == keyboard.Key.left:
                self.get_logger().info("Left")
                msg = String()
                msg.data = "Left"
                self.publisher_.publish(msg)
            elif key == keyboard.Key.right:
                self.get_logger().info("Right")
                msg = String()
                msg.data = "Right"
                self.publisher_.publish(msg)
        except AttributeError:
            pass

def main(args=None):
    rclpy.init(args=args)
    node = MyNode()

    # Start the keyboard listener
    node.listener.start()

    rclpy.spin(node)

    # Stop the keyboard listener
    node.listener.stop()

    rclpy.shutdown()

if __name__ == '__main__':
    main()
