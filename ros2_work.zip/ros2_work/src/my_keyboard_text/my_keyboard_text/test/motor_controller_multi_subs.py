#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
from std_srvs.srv import SetBool

class MotorSubscriber(Node):
    def __init__(self):
        super().__init__('motor_subscriber')
        self.subscription = self.create_subscription(Bool, 'motor_control', self.listener_callback, 10)
        self.subscription

    def listener_callback(self, msg):
        if msg.data:
            # Turn motors on
            motor1_on_request = SetBool.Request()
            motor1_on_request.data = True
            motor2_on_request = SetBool.Request()
            motor2_on_request.data = True
            self.on_service.call_async(motor1_on_request)
            self.on_service.call_async(motor2_on_request)
        else:
            # Turn motors off
            motor1_off_request = SetBool.Request()
            motor1_off_request.data = False
            motor2_off_request = SetBool.Request()
            motor2_off_request.data = False
            self.off_service.call_async(motor1_off_request)
            self.off_service.call_async(motor2_off_request)

def main(args=None):
    rclpy.init(args=args)
    motor_subscriber = MotorSubscriber()
    rclpy.spin(motor_subscriber)
    motor_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
