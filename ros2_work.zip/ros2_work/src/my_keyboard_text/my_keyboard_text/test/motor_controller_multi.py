#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
from std_srvs.srv import SetBool
from pynput import keyboard

class MotorSubscriber(Node):
    def __init__(self):
        super().__init__('motor_subscriber')
        self.subscription = self.create_subscription(Bool, 'motor_control', self.listener_callback, 10)
        self.subscription

        # Initialize keyboard listener
        self.listener = keyboard.Listener(on_press=self.on_press)
        self.listener.start()

    def listener_callback(self, msg):
        pass  # This method is no longer used for controlling motors

    def on_press(self, key):
        # Define the key bindings for controlling motors
        if key == keyboard.Key.up:
            self.turn_motors_on()
        elif key == keyboard.Key.down:
            self.turn_motors_off()

    def turn_motors_on(self):
        # Turn motors on
        motor1_on_request = SetBool.Request()
        motor1_on_request.data = True
        motor2_on_request = SetBool.Request()
        motor2_on_request.data = True
        self.on_service.call_async(motor1_on_request)
        self.on_service.call_async(motor2_on_request)

    def turn_motors_off(self):
        # Turn motors off
        motor1_off_request = SetBool.Request()
        motor1_off_request.data = False
        motor2_off_request = SetBool.Request()
        motor2_off_request.data = False
        self.off_service.call_async(motor1_off_request)
        self.off_service.call_async(motor2_off_request)

def main(args=None):
    rclpy.init(args=args)
    motor_subscriber = MotorSubscriber()
    rclpy.spin(motor_subscriber)
    motor_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
