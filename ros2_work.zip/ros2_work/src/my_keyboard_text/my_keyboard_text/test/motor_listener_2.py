#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class KeyboardListener(Node):
    def __init__(self):
        super().__init__("Keyboard_Listener_Node")
        self.get_logger().info("Listening to keyboard input")
        self.subscription = self.create_subscription(
            Twist,
            'keyboard_input',
            self.listener_callback,
            10)
        self.subscription

    def listener_callback(self, msg):
        linear_x = msg.linear.x
        linear_y = msg.linear.y

        # angular_z = msg.angular.z

        self.get_logger().info(f"Linear X: {linear_x},Linear Y: {linear_y}")

def main(args=None):
    rclpy.init(args=args)
    node = KeyboardListener()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
