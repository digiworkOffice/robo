#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
from std_msgs.msg import String
import numpy as np


class FaceDetector(Node):
    def __init__(self):
        super().__init__("Face_Detector_Node")
        self.get_logger().info("Initializing Face Detector Node")
        self.subscription = self.create_subscription(Image, '/image_raw', self.image_callback, 10)
        self.subscription 
        self.publisher_ = self.create_publisher(String, '/detected_hand_controller', 10)
        self.bridge = CvBridge()
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')


    def image_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")

        

        cv2.imshow('img', frame)
        cv2.waitKey(1)


    def publish_face_coordinates(self, value):
        face_point = String()
        face_point.data = str(value)  # Convert value to string
        # Publish the Point message containing face coordinates
        self.publisher_.publish(face_point)

        self.get_logger().info(f"Detected face at: ({value}")


def main(args=None):
    rclpy.init(args=args)
    node = FaceDetector()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
