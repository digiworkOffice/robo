#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
from std_msgs.msg import String

class FaceDetector(Node):
    def __init__(self):
        super().__init__("Face_Detector_Node")
        self.get_logger().info("Initializing Face Detector Node")
        self.subscription = self.create_subscription(Image, '/image_raw', self.image_callback, 10)
        self.subscription  # prevent unused variable warning
        self.publisher_ = self.create_publisher(String, '/detected_face_coordinates', 10)
        self.bridge = CvBridge()
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')


    def image_callback(self, msg):
        current_face_id = None
        frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")

        # Convert frame to grayscale for face detection
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detect faces in the grayscale frame
        faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)

        if len(faces) > 0:
            if current_face_id is not None:
                matching_faces = [face for face in faces if face[-1] == current_face_id]

                if len(matching_faces) > 0:
                    x, y, w, h = matching_faces[0][:4]
                else:
                    x, y, w, h = faces[0][:4]
                    current_face_id = faces[0][-1]
                    servo_x = int((x + w // 2) * (70 - 179) / 640 + 179)
                    servo_y = int((y + h // 2) * (179 - 95) / 480 + 95)
                    string = 'X{0:d}Y{1:d}'.format(servo_x, servo_y)
                    self.publish_face_coordinates(string)

            else:
                x, y, w, h = faces[0][:4]
                current_face_id = faces[0][-1]
                servo_x = int((x + w // 2) * (70 - 179) / 640 + 179)
                servo_y = int((y + h // 2) * (179 - 95) / 480 + 95)
                string = 'X{0:d}Y{1:d}'.format(servo_x, servo_y)
                self.publish_face_coordinates(string)

            cv2.circle(frame, (x + w // 2, y + h // 2), 2, (0, 255, 0), 2)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 3)

        cv2.rectangle(frame, (640 // 2 - 30, 480 // 2 - 30),
                  (640 // 2 + 30, 480 // 2 + 30),
                  (255, 255, 255), 3)

            
        cv2.imshow('img', frame)
        cv2.waitKey(1)  

    def publish_face_coordinates(self, value):
        face_point = String()
        face_point.data = value

        # Publish the Point message containing face coordinates
        self.publisher_.publish(face_point)

        self.get_logger().info(f"Detected face at: ({value}")


def main(args=None):
    rclpy.init(args=args)
    node = FaceDetector()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
